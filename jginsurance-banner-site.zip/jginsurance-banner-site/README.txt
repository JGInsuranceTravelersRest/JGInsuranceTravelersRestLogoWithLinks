JGInsurance Banner Site (Netlify-ready)
=========================================

How to deploy:
1) Unzip this folder.
2) Visit https://app.netlify.com/drop
3) Drag the *folder named* `jginsurance-banner-site` onto the Drop area.
   (Do NOT drag just index.html; upload the whole folder.)
4) Netlify will host it and give you a public link like https://yourname.netlify.app

What's inside:
- index.html         (your clickable banner page)
- assets/style.css   (gold-on-black styles)
- assets/logo.jpg    (your ornate logo image)

You can rename the site inside Netlify settings for a cleaner URL.
